react 父子组件   prop-types
ts   语法解决这个问题

{ title: string, content: string }
ts 类型约束

{ key: val, key2: val2 }
面向对象， 面向接口( interface )的编程是设计模式的基础

typescript   interface   关键字

运行一个 ts + react 项目需要哪些前端技术
1. webpack
  .tsx
2. tsconfig.json jsx -> react ts -> js
3. babel